package com.epam.rd.autotasks;

public class CarouselRun {

    public int next() {
       throw new UnsupportedOperationException();
    }

    public boolean isFinished() {
        throw new UnsupportedOperationException();
    }

}

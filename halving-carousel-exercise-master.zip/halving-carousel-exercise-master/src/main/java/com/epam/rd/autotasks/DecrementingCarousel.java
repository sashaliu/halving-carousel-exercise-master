package com.epam.rd.autotasks;

public class DecrementingCarousel {
    public DecrementingCarousel(int capacity) {

    }

    public boolean addElement(int element){
        throw new UnsupportedOperationException();
    }

    public CarouselRun run(){
       throw new UnsupportedOperationException();
    }
}
